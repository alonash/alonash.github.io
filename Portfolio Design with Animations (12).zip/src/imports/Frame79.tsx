export default function Frame() {
  return (
    <div className="bg-white relative size-full">
      <div className="absolute h-[206px] left-[80px] top-[1310px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[435px] top-[1310px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[790px] top-[1310px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1145px] top-[1310px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1500px] top-[1310px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1861px] top-[1310px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[80px] top-[1064px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[435px] top-[1064px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[790px] top-[1064px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1145px] top-[1064px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1500px] top-[1064px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1861px] top-[1064px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1861px] top-[326px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[80px] top-[818px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[435px] top-[818px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[790px] top-[818px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1145px] top-[818px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1500px] top-[818px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1861px] top-[818px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1861px] top-[80px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[80px] top-[572px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[435px] top-[572px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[790px] top-[572px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1145px] top-[572px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1500px] top-[572px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1861px] top-[572px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[80px] top-[1556px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[435px] top-[1556px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[790px] top-[1556px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1145px] top-[1556px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1500px] top-[1556px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute h-[206px] left-[1861px] top-[1556px] w-[307px]" data-name="Card-Regular">
        <div className="absolute bg-white inset-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.08)]" data-name="Card-Regular" />
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[80px] top-[1310px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#3b6ff0] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[435px] top-[1310px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#34897b] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[790px] top-[1310px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#55c06f] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1145px] top-[1310px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#f88813] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1500px] top-[1310px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#fa4500] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1861px] top-[1310px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#3a4147] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[80px] top-[1064px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#7197f4] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[435px] top-[1064px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#46b9a6] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[790px] top-[1064px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#8fd6a1] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1145px] top-[1064px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#fbb46a] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1500px] top-[1064px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#ff6b33] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1861px] top-[1064px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#788386] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1861px] top-[326px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#f5f7fa] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[80px] top-[818px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#a0b9f8] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[435px] top-[818px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#90d5ca] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[790px] top-[818px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#b4e4c0] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1145px] top-[818px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#fccd9c] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1500px] top-[818px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#ffb599] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1861px] top-[818px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#d9dfe7] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1861px] top-[80px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-white h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[80px] top-[572px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#f0f4ff] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[435px] top-[572px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#bef8ea] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[790px] top-[572px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#deffdd] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1145px] top-[572px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#ffeedd] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1500px] top-[572px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#ffe9e1] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1861px] top-[572px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#e8edf2] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[80px] top-[1556px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#1049d5] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[435px] top-[1556px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#2a6f64] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[790px] top-[1556px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#37954e] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1145px] top-[1556px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#c66806] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1500px] top-[1556px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-[#cc3800] h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <div className="absolute flex h-[calc(1px*((var(--transform-inner-width)*1)+(var(--transform-inner-height)*0)))] items-center justify-center left-[1861px] top-[1556px] w-[calc(1px*((var(--transform-inner-height)*1)+(var(--transform-inner-width)*0)))]" style={{ "--transform-inner-width": "98", "--transform-inner-height": "307" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="bg-black h-[307px] rounded-bl-[8px] rounded-tl-[8px] w-[98px]" data-name="Blue (Brand)" />
        </div>
      </div>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[100px] not-italic text-[#788386] text-[16px] text-nowrap top-[1428px] whitespace-pre">@blue-brand</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[455px] not-italic text-[#788386] text-[16px] text-nowrap top-[1428px] whitespace-pre">@forest-37</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[810px] not-italic text-[#788386] text-[16px] text-nowrap top-[1428px] whitespace-pre">@green-54</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1165px] not-italic text-[#788386] text-[16px] text-nowrap top-[1428px] whitespace-pre">@orange-52</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1520px] not-italic text-[#788386] text-[16px] text-nowrap top-[1428px] whitespace-pre">@red-49-Brand</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#788386] text-[16px] text-nowrap top-[1428px] whitespace-pre">@gray-font-dark</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[100px] not-italic text-[#788386] text-[16px] text-nowrap top-[1182px] whitespace-pre">@blue-70</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[455px] not-italic text-[#788386] text-[16px] text-nowrap top-[1182px] whitespace-pre">@forest-40</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[810px] not-italic text-[#788386] text-[16px] text-nowrap top-[1182px] whitespace-pre">@green-70</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1165px] not-italic text-[#788386] text-[16px] text-nowrap top-[1182px] whitespace-pre">@orange-70</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1520px] not-italic text-[#788386] text-[16px] text-nowrap top-[1182px] whitespace-pre">@red-60</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#788386] text-[16px] text-nowrap top-[1182px] whitespace-pre">@gray-font-light</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#788386] text-[16px] text-nowrap top-[444px] whitespace-pre">@gray-97</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[100px] not-italic text-[#788386] text-[16px] text-nowrap top-[936px] whitespace-pre">@blue-80</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[455px] not-italic text-[#788386] text-[16px] text-nowrap top-[936px] whitespace-pre">@forest-70</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[810px] not-italic text-[#788386] text-[16px] text-nowrap top-[936px] whitespace-pre">@green-10</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1165px] not-italic text-[#788386] text-[16px] text-nowrap top-[936px] whitespace-pre">@orange-80</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1520px] not-italic text-[#788386] text-[16px] text-nowrap top-[936px] whitespace-pre">@red-80</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#788386] text-[16px] text-nowrap top-[936px] whitespace-pre">@gray-76</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#788386] text-[16px] text-nowrap top-[198px] whitespace-pre">@white</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[100px] not-italic text-[#788386] text-[16px] text-nowrap top-[690px] whitespace-pre">@blue-bg</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[455px] not-italic text-[#788386] text-[16px] text-nowrap top-[690px] whitespace-pre">@forest-bg</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[810px] not-italic text-[#788386] text-[16px] text-nowrap top-[690px] whitespace-pre">@green-bg</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1165px] not-italic text-[#788386] text-[16px] text-nowrap top-[690px] whitespace-pre">@orange-bg</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1520px] not-italic text-[#788386] text-[16px] text-nowrap top-[690px] whitespace-pre">@red-bg</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#788386] text-[16px] text-nowrap top-[690px] whitespace-pre">@gray-93</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[100px] not-italic text-[#788386] text-[16px] text-nowrap top-[1674px] whitespace-pre">@blue-dark</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[455px] not-italic text-[#788386] text-[16px] text-nowrap top-[1674px] whitespace-pre">@forest-30</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[810px] not-italic text-[#788386] text-[16px] text-nowrap top-[1674px] whitespace-pre">@green-40</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1165px] not-italic text-[#788386] text-[16px] text-nowrap top-[1674px] whitespace-pre">@orange-40</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1520px] not-italic text-[#788386] text-[16px] text-nowrap top-[1674px] whitespace-pre">@red-40</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#788386] text-[16px] text-nowrap top-[1674px] whitespace-pre">@black</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[100px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1464px] whitespace-pre">#3b6ff0</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[455px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1464px] whitespace-pre">#34897b</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[810px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1464px] whitespace-pre">#55c06f</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1165px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1464px] whitespace-pre">#f88813</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1520px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1464px] whitespace-pre">#fa4500</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1464px] whitespace-pre">#3a4147</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[100px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1218px] whitespace-pre">#7197f4</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[455px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1218px] whitespace-pre">#46b9a6</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[810px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1218px] whitespace-pre">#8fd6a1</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1165px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1218px] whitespace-pre">#fbb46a</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1520px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1218px] whitespace-pre">#ff6b33</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1218px] whitespace-pre">#788386</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[480px] whitespace-pre">#f5f7fa</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[100px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[972px] whitespace-pre">#a0b9f8</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[455px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[972px] whitespace-pre">#90d5ca</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[810px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[972px] whitespace-pre">#b4e4c0</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1165px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[972px] whitespace-pre">#fccd9c</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1520px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[972px] whitespace-pre">#ffb599</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[972px] whitespace-pre">#d3d8e1</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[234px] whitespace-pre">#ffffff</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[100px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[726px] whitespace-pre">#f0f4ff</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[455px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[726px] whitespace-pre">#bef8ea</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[810px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[726px] whitespace-pre">#deffdd</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1165px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[726px] whitespace-pre">#ffeedd</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1520px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[726px] whitespace-pre">#ffe9e1</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[726px] whitespace-pre">#e8edf2</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[100px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1710px] whitespace-pre">#1049d5</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[455px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1710px] whitespace-pre">#2a6f64</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[810px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1710px] whitespace-pre">#37954e</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1165px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1710px] whitespace-pre">#c66806</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1520px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1710px] whitespace-pre">#cc3800</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[1881px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[1710px] whitespace-pre">#000000</p>
      <div className="absolute h-0 left-[1861px] top-[179px] w-[307px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 307 1">
            <line id="Line 27" stroke="var(--stroke-0, #E8EDF2)" x2="307" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[80px] not-italic text-[#3a4147] text-[16px] text-nowrap top-[80px] whitespace-pre">Design Guide</p>
      <p className="absolute font-['TT_Commons:Regular',sans-serif] leading-[20px] left-[80px] not-italic text-[#d9dfe7] text-[16px] text-nowrap top-[160px] whitespace-pre">Colors</p>
    </div>
  );
}