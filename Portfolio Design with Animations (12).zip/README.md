
  # Portfolio Design with Animations

  This is a code bundle for Portfolio Design with Animations. The original project is available at https://www.figma.com/design/sJsMlude0mw6uKlkrfKd7v/Portfolio-Design-with-Animations.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  